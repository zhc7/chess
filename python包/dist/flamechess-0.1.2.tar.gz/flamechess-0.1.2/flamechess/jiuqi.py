class Game:
    def __init__(self):
        pass

    def available_actions(self):
        pass

    def next_state(self, state, action):
        pass

    def is_win(self):
        pass

